#define addressBits 48

int cacheSize = 0;
int blockSize = 0;
int offsetBits = 0;
int numberOfSets = 0;
int tagBits = 0;
int indexBits = 0;
char binaryadd[addressBits];
int misses = 0;
int numberOfHits = 0;
int reads = 0;
int writes = 0;
int indexx = 0;


int policy = 0; 
int assoc = 0;
int assocNumber = -1;

void getBinary(char hexa[]);
void verify();
void verifyass();
void writeThroughCache(char tag[], int indeX, int sets[], char valuesOfSets[numberOfSets][tagBits]);
void readFromCache(char tag[], int indeX, int sets[], char valuesOfSets[numberOfSets][tagBits]);
int binaryToDecimal(int n);
unsigned int log2n(unsigned int n);
